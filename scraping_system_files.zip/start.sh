DOCKER_USER="chancewave"
DOCKER_PASS="ai02140214"
docker login --username=$DOCKER_USER --password=$DOCKER_PASS
docker-compose up